//
//  Example4Tests.swift
//  Example4Tests
//
//  Created by User-UAM on 10/15/24.
//

import XCTest
@testable import Example4

class Example4Tests: XCTestCase {


    func testExample() throws {
        
        class PalindromoTests: XCTestCase {
            func testPalabraEsPalindromo() {
                let palindromo = Palindromo()
                XCTAssertTrue(palindromo.esPalindromo("Reconocer"))
                XCTAssertTrue(palindromo.esPalindromo("anilina"))
                XCTAssertTrue(palindromo.esPalindromo("radar"))
            }
            
            func testFraseEsPalindromo() {
                let palindromo = Palindromo()
                XCTAssertTrue(palindromo.esPalindromo("Anita lava la tina"))
                XCTAssertTrue(palindromo.esPalindromo("Roma ni se conoce sin oro, ni se conoce sin amor"))
            }
        }
    }
}
