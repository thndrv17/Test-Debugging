//
//  Palindromo.swift
//  Example4
//
//  Created by User-UAM on 10/15/24.
//

import Foundation
import UIKit

class Palindromo {
    func esPalindromo(_ cadena: String) -> Bool {
        let texto = cadena.lowercased().filter { $0.isLetter }
        return texto == String(texto.reversed())
    }
}


