//
//  Example3Tests.swift
//  Example3Tests
//
//  Created by User-UAM on 10/15/24.
//

import XCTest
@testable import Example3

class Example3Tests: XCTestCase {

    func testExample() throws {
        class NumeroTests: XCTestCase {
            func testEsPar() {
                let numero = Numero()
                XCTAssertTrue(numero.esPar(4))
            }
            
            func testEsImpar() {
                let numero = Numero()
                XCTAssertFalse(numero.esPar(5))
            }
        }
        
    }

}
