//
//  Par_Impar.swift
//  Example3
//
//  Created by User-UAM on 10/15/24.
//

import Foundation
import UIKit

class Numero {
    func esPar(_ numero: Int) -> Bool {
        return numero % 2 == 0
    }
}


