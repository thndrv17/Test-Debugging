//
//  AreaTrianguloCode.swift
//  Example2
//
//  Created by User-UAM on 10/15/24.
//

import Foundation
import UIKit
/* Crea una clase que calcule el área de un triángulo dado su base y altura. Realiza las pruebas
unitarias para validar el resultado.
1. Crea la prueba unitaria para validar el resultado del cálculo del área de un triángulo */

class Triangulo {
    var base: Double
    var altura: Double
    
    init(base: Double, altura: Double) {
        self.base = base
        self.altura = altura
    }
    
    func calcularArea() -> Double {
        return (base * altura) / 2
    }
}


