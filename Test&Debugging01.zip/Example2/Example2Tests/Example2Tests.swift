//
//  Example2Tests.swift
//  Example2Tests
//
//  Created by User-UAM on 10/15/24.
//

import XCTest
@testable import Example2

class Example2Tests: XCTestCase {

   

    func testExample() throws {
        class TrianguloTests: XCTestCase {
            func testCalcularArea() {
                let triangulo = Triangulo(base: 10, altura: 5)
                let area = triangulo.calcularArea()
                XCTAssertEqual(area, 25)
            }
        }

    }

}
