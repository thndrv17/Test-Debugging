//
//  CalculatorCode.swift
//  Example1
//
//  Created by User-UAM on 10/15/24.
//

import Foundation
import UIKit

class Calculadora {
    func potencia(base: Double, exponente: Double) -> Double {
        return pow(base, exponente)
    }
}
