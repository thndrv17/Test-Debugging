//
//  Example1_Tests.swift
//  Example1_Tests
//
//  Created by User-UAM on 10/15/24.
//

import XCTest
@testable import Example1

class Example1_Tests: XCTestCase {


    func testExample() throws {
       
        class CalculadoraTests: XCTestCase {
            var calculadora: Calculadora!

            override func setUp() {
                super.setUp()
                calculadora = Calculadora()
            }

            // 1. Prueba unitaria para validar la potencia de un número
            func testPotencia() {
                let resultado = calculadora.potencia(base: 2, exponente: 3)
                XCTAssertEqual(resultado, 8, "La potencia de 2^3 debería ser 8")
            }

            // 2. Prueba unitaria para validar que un número a la potencia 0 es igual a 1
            func testPotenciaCero() {
                let resultado = calculadora.potencia(base: 5, exponente: 0)
                XCTAssertEqual(resultado, 1, "Cualquier número a la potencia 0 debería ser 1")
            }
        }
        
    }

}
