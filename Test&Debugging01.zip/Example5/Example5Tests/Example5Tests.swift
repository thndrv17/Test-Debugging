//
//  Example5Tests.swift
//  Example5Tests
//
//  Created by User-UAM on 10/15/24.
//

import XCTest
@testable import Example5

class Example5Tests: XCTestCase {

    func testExample() throws {

        class ContadorDeVocalesTests: XCTestCase {
            func testContarVocalesEnTexto() {
                let contador = ContadorDeVocales()
                XCTAssertEqual(contador.contarVocales("hola mundo"), 4)
            }
            
            func testContarVocalesEnTextoSinSentido() {
                let contador = ContadorDeVocales()
                XCTAssertEqual(contador.contarVocales("bcdfghjkl"), 0)
            }
        }
    }
}
