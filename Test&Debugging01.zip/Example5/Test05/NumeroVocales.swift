//
//  NumeroVocales.swift
//  Example5
//
//  Created by User-UAM on 10/15/24.
//

import Foundation
import UIKit

class ContadorDeVocales {
    func contarVocales(_ cadena: String) -> Int {
        let vocales = "aeiouAEIOU"
        return cadena.filter { vocales.contains($0) }.count
    }
}
