//
//  Principal_ViewTests.swift
//  Principal ViewTests
//
//  Created by User-UAM on 10/31/24.
//

import XCTest
@testable import Principal_View

class ViewControllerTests: XCTestCase {
    
    var viewController: ViewController!
    
    override func setUpWithError() throws {
        viewController = ViewController()
        viewController.loadViewIfNeeded()
    }
    
    override func tearDownWithError() throws {
        viewController = nil
    }
    
    func testElementsExist() throws {
        let header = viewController.tableView.dequeueReusableHeaderFooterView(withIdentifier: "HeaderView") as? HeaderView
        XCTAssertNotNil(header, "HeaderView should exist")
        
        let profileImage = viewController.tableView.dequeueReusableHeaderFooterView(withIdentifier: "ProfileImageView") as? ProfileImageView
        XCTAssertNotNil(profileImage, "ProfileImageView should exist")
        
        let card = viewController.tableView.dequeueReusableCell(withIdentifier: "CardView") as? CardView
        XCTAssertNotNil(card, "CardView should exist")
        
        let cell = viewController.tableView.dequeueReusableCell(withIdentifier: "cell")
        XCTAssertNotNil(cell, "UITableViewCell should exist")
    }
    
    func testElementsAreInteractable() throws {
        let header = viewController.tableView.dequeueReusableHeaderFooterView(withIdentifier: "HeaderView") as? HeaderView
        XCTAssertTrue(header?.isUserInteractionEnabled ?? false, "HeaderView should be interactable")
        
        let profileImage = viewController.tableView.dequeueReusableHeaderFooterView(withIdentifier: "ProfileImageView") as? ProfileImageView
        XCTAssertTrue(profileImage?.isUserInteractionEnabled ?? false, "ProfileImageView should be interactable")
        
        let card = viewController.tableView.dequeueReusableCell(withIdentifier: "CardView") as? CardView
        XCTAssertTrue(card?.isUserInteractionEnabled ?? false, "CardView should be interactable")
        
        let cell = viewController.tableView.dequeueReusableCell(withIdentifier: "cell")
        XCTAssertTrue(cell?.isUserInteractionEnabled ?? false, "UITableViewCell should be interactable")
    }
    
    func testFirstAndLastCellsAreVisible() throws {
        viewController.loadViewIfNeeded()
        viewController.tableView.layoutIfNeeded()
        
        let firstIndexPath = IndexPath(row: 0, section: 2)
        let lastIndexPath = IndexPath(row: 3, section: 2) // Assuming there are 3 list items
        
        guard let firstCell = viewController.tableView.cellForRow(at: firstIndexPath) else {
            XCTFail("First cell should exist")
            return
        }
        guard let lastCell = viewController.tableView.cellForRow(at: lastIndexPath) else {
            XCTFail("Last cell should exist")
            return
        }
        
        XCTAssertTrue(viewController.tableView.visibleCells.contains(firstCell), "First cell should be visible")
        XCTAssertTrue(viewController.tableView.visibleCells.contains(lastCell), "Last cell should be visible")
    }
}
