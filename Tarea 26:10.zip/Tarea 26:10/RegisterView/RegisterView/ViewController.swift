//
//  ViewController.swift
//  RegisterView
//
//  Created by LABORATORIO MAC UAM on 26/10/24.
//
import UIKit

class RegisterViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
    }

    func setupUI() {
        view.backgroundColor = .white
        
        let nameTextField = createTextField(placeholder: "Name")
        let userIDTextField = createTextField(placeholder: "UserID")
        let phoneTextField = createTextField(placeholder: "Phone")
        let passwordTextField = createTextField(placeholder: "Password", isSecure: true)
        let repeatPasswordTextField = createTextField(placeholder: "Repeat Password", isSecure: true)
        let registerButton = createButton(title: "Register")
        
        let stackView = UIStackView(arrangedSubviews: [nameTextField, userIDTextField, phoneTextField, passwordTextField, repeatPasswordTextField, registerButton])
        stackView.axis = .vertical
        stackView.spacing = 20
        stackView.translatesAutoresizingMaskIntoConstraints = false
        
        view.addSubview(stackView)
        
        NSLayoutConstraint.activate([
            stackView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            stackView.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            stackView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            stackView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20)
        ])
    }
    
    func createTextField(placeholder: String, isSecure: Bool = false) -> UITextField {
        let textField = UITextField()
        textField.placeholder = placeholder
        textField.borderStyle = .roundedRect
        textField.isSecureTextEntry = isSecure
        textField.translatesAutoresizingMaskIntoConstraints = false
        return textField
    }
    
    func createButton(title: String) -> UIButton {
        let button = UIButton(type: .system)
        button.setTitle(title, for: .normal)
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }
}

// Presentando el RegisterViewController desde otra vista:
class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white

        let registerButton = UIButton(type: .system)
        registerButton.setTitle("Go to Register", for: .normal)
        registerButton.addTarget(self, action: #selector(openRegister), for: .touchUpInside)
        registerButton.translatesAutoresizingMaskIntoConstraints = false

        view.addSubview(registerButton)

        NSLayoutConstraint.activate([
            registerButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            registerButton.centerYAnchor.constraint(equalTo: view.centerYAnchor)
        ])
    }

    @objc func openRegister() {
        let registerVC = RegisterViewController()
        navigationController?.pushViewController(registerVC, animated: true)
    }
}

