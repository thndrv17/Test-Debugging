//
//  RegisterViewTests.swift
//  RegisterViewTests
//
//  Created by LABORATORIO MAC UAM on 26/10/24.
//

import XCTest
@testable import RegisterView

class RegisterViewControllerTests: XCTestCase {
    
    var viewController: RegisterViewController!
    
    override func setUpWithError() throws {
        viewController = RegisterViewController()
        viewController.loadViewIfNeeded()
    }
    
    override func tearDownWithError() throws {
        viewController = nil
    }
    
    func testElementsExist() throws {
        let textFieldsPlaceholders = ["Name", "UserID", "Phone", "Password", "Repeat Password"]
        let buttonsTitles = ["Register"]
        
        for subview in viewController.view.subviews {
            if let stackView = subview as? UIStackView {
                for arrangedSubview in stackView.arrangedSubviews {
                    if let textField = arrangedSubview as? UITextField, let placeholder = textField.placeholder {
                        XCTAssertTrue(textFieldsPlaceholders.contains(placeholder), "Text field with placeholder '\(placeholder)' should exist")
                    } else if let button = arrangedSubview as? UIButton, let title = button.title(for: .normal) {
                        XCTAssertTrue(buttonsTitles.contains(title), "Button with title '\(title)' should exist")
                    }
                }
            }
        }
    }
    
    func testElementsAreInteractable() throws {
        let subviews = viewController.view.subviews
        
        for view in subviews {
            if let stackView = view as? UIStackView {
                for arrangedSubview in stackView.arrangedSubviews {
                    if let textField = arrangedSubview as? UITextField {
                        XCTAssertTrue(textField.isUserInteractionEnabled, "\(textField.placeholder ?? "Text field") should be interactable")
                    } else if let button = arrangedSubview as? UIButton {
                        XCTAssertTrue(button.isUserInteractionEnabled, "\(button.title(for: .normal) ?? "Button") should be interactable")
                    }
                }
            }
        }
    }
}
