//
//  LoginViewTests.swift
//  LoginViewTests
//
//  Created by LABORATORIO MAC UAM on 26/10/24.
//

import XCTest
@testable import LoginView

class ViewControllerTests: XCTestCase {
    
    var viewController: ViewController!
    
    override func setUpWithError() throws {
        viewController = ViewController()
        viewController.loadViewIfNeeded()
    }
    
    override func tearDownWithError() throws {
        viewController = nil
    }
    
    func testElementsExist() throws {
        XCTAssertNotNil(viewController.uiTextLabel, "uiTextLabel no debe de ser nil")
        XCTAssertNotNil(viewController.uiTextField, "uiTextField no debe de ser nil")
        XCTAssertNotNil(viewController.uiPasswordTextField, "uiPasswordTextField no debe de ser nil")
        XCTAssertNotNil(viewController.uiButton, "uiButton no debe de ser nil")
        XCTAssertNotNil(viewController.registerButton, "registerButton no debe de ser nil")
    }
    
    func testElementsAreInteractable() throws {
        XCTAssertTrue(viewController.uiTextLabel.isUserInteractionEnabled, "uiTextLabel debe de ser interactuable")
        XCTAssertTrue(viewController.uiTextField.isUserInteractionEnabled, "uiTextField debe de ser interactuable")
        XCTAssertTrue(viewController.uiPasswordTextField.isUserInteractionEnabled, "uiPasswordTextField debe de ser interactuable")
        XCTAssertTrue(viewController.uiButton.isUserInteractionEnabled, "uiButton debe de ser interactuable")
        XCTAssertTrue(viewController.registerButton.isUserInteractionEnabled, "registerButton debe de ser interactuable")
    }
}
