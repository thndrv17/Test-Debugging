import XCTest
@testable import LoginExample

final class LoginExampleTests: XCTestCase {

    func testExample() throws {
    }

}
