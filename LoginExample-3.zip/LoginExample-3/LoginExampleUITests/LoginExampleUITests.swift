//
//  LoginExampleUITests.swift
//  LoginExampleUITests
//
//  Created by User-U on 5/12/23.
//

import XCTest

final class LoginExampleUITests: XCTestCase {

    override func setUpWithError() throws {
    }

    func testExample() throws {
        let app = XCUIApplication()
        app.launch()
    }
}
