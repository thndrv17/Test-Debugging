//
//  RegisterViewController.swift
//  LoginExample
//
//  Created by User on 5/12/23.
//

import UIKit

class RegisterViewController: UIViewController {

    @IBOutlet var userTextField: UITextField!
    @IBOutlet var passwordTextField: UITextField!
    @IBOutlet var errorLabel: UILabel!
    @IBOutlet var registerButton: UIButton!
        
        override func viewDidLoad() {
            super.viewDidLoad()
            errorLabel.text = ""
            registerButton.addTarget(self, action: #selector(validateUser), for: .touchUpInside)
        }
        
        @objc func validateUser(sender: UIButton!) {
            guard let username = userTextField.text, !username.isEmpty,
                  let password = passwordTextField.text, !password.isEmpty else {
                showAlert(title: "Error", message: "Por favor complete todos los campos")
                return
            }
            
            if isValidRegistration(username: username, password: password) {
                showAlert(title: "Éxito", message: "Registro exitoso")
            } else {
                showAlert(title: "Error", message: "Formato de email inválido o contraseña demasiado corta")
            }
        }
        
        func showAlert(title: String, message: String) {
            let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
            let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
            alertController.addAction(okAction)
            self.present(alertController, animated: true, completion: nil)
        }
        
        func isValidRegistration(username: String, password: String) -> Bool {
            // Verificando que el usuario y la contraseña cumplen con los criterios de validación.
            let validEmail = username.contains("@")
            let validPassword = password.count >= 8 // Ejemplo de validación de contraseña
            return validEmail && validPassword
        }
    }

