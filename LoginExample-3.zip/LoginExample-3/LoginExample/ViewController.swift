import UIKit

class ViewController: UIViewController {
    
    @IBOutlet var userTextFiel: UITextField!
    @IBOutlet var passwordTextFiel: UITextField!
    @IBOutlet var loginButton: UIButton!
    @IBOutlet var registerButton: UIButton!
    @IBOutlet var loginValidationLabel: UILabel!
    
        override func viewDidLoad() {
            super.viewDidLoad()
            loginButton.addTarget(self, action: #selector(navigateToMainView), for: .touchUpInside)
            registerButton.addTarget(self, action: #selector(navigateToRegisterView), for: .touchUpInside)
            setValidationLabel()
        }
        
        @objc func navigateToMainView(sender: UIButton!) {
            guard let username = userTextFiel.text, !username.isEmpty,
                  let password = passwordTextFiel.text, !password.isEmpty else {
                showAlert(title: "Error", message: "Por favor complete todos los campos")
                return
            }
            
            if isValidCredentials(username: username, password: password) {
                let mainViewController = MainViewController()
                self.navigationController?.pushViewController(mainViewController, animated: true)
                setValidationLabel()
            } else {
                showAlert(title: "Error", message: "Usuario o contraseña incorrectos")
            }
        }
        
        @objc func navigateToRegisterView(sender: UIButton!) {
            let registerViewController = RegisterViewController()
            self.navigationController?.pushViewController(registerViewController, animated: true)
        }
        
        func setValidationLabel() {
            loginValidationLabel.text = ""
            loginValidationLabel.textColor = .black
        }
        
        func showAlert(title: String, message: String) {
            let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
            let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
            alertController.addAction(okAction)
            self.present(alertController, animated: true, completion: nil)
        }
        
        func isValidCredentials(username: String, password: String) -> Bool {
            // Simulando una verificación de credenciales de una base de datos.
            return username == "Admin" && password == "Admin123"
        }
    }


