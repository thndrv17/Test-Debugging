import UIKit

class MainViewController: UIViewController {

    @IBOutlet var userImageView: UIImageView!
    @IBOutlet var mainMessageLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
}
